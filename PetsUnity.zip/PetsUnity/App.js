import React, { Component } from "react";
import { createStackNavigator, createAppContainer, createBottomTabNavigator } from "react-navigation";
import Ionicons from 'react-native-vector-icons/Ionicons'
import Stores from './components/stores/Stores';
import StoreDetails from './components/stores/StoreDetails';
import ProductDetails from './components/stores/ProductDetails';
import SplashScreen from './pages/SplashScreen';
import OnboardingScreen from './pages/OnboardingScreen';
import Articles from './components/articles/Articles';
import ArticleDetails from './components/articles/ArticleDetails';
import Clinics from './components/clinics/Clinics';
import ClinicDetails from './components/clinics/ClinicDetails';
import News from './components/news/News';
import NewsDetails from './components/news/NewsDetails';
import Profile from './components/profile/Profile';
import Posts from './components/posts/Posts';
import PostDetails from './components/posts/PostDetails';
import Map from './components/map/Map';
import Login from './components/login/Login';

const ClinicsStack = createStackNavigator({

  Clinics: Clinics,
  ClinicDetails: ClinicDetails
},
  {

    defaultNavigationOptions: {
      header: null,
    }
  }
)
const ArticlesStack = createStackNavigator({
  Articles: Articles,
  ArticleDetails: ArticleDetails
},
  {

    defaultNavigationOptions: {
      header: null,
    }
  }
)
const PostsStack = createStackNavigator({
  Posts: Posts,
  PostDetails: PostDetails
},
  {

    defaultNavigationOptions: {
      header: null,
    }
  }
)
const NewsStack = createStackNavigator({
  News: News,
  Profile: Profile,
  NewsDetails: NewsDetails
},
  {

    defaultNavigationOptions: {
      header: null,
    }
  }
)
const StoresStack = createStackNavigator({
  Stores: Stores,
  StoreDetails: StoreDetails,
  ProductDetails: ProductDetails

},
  {

    defaultNavigationOptions: {
      header: null,
    }
  }
)
const mainNavigator = createBottomTabNavigator(
  {

    News: {
      screen: NewsStack,
      navigationOptions: () => ({
        tabBarIcon: ({ tintColor }) => (
          <Ionicons name="logo-rss" size={24} color={tintColor} > </Ionicons >
        )

      })
    },
    Articles: {
      screen: ArticlesStack,
      navigationOptions: () => ({
        tabBarIcon: ({ tintColor }) => (
          <Ionicons name="md-clipboard" size={24} color={tintColor} ></Ionicons >
        )

      })
    },
    Clinics: {
      screen: ClinicsStack,
      navigationOptions: () => ({
        tabBarIcon: ({ tintColor }) => (
          <Ionicons name="ios-medkit" size={24} color={tintColor} > </Ionicons >
        )

      })
    },
    Stores: {
      screen: StoresStack,
      navigationOptions: () => ({
        tabBarIcon: ({ tintColor }) => (
          <Ionicons name="ios-cart" size={24} color={tintColor} ></Ionicons >
        )

      })
    },


    Posts: {
      screen: PostsStack,
      navigationOptions: () => ({
        tabBarIcon: ({ tintColor }) => (
          <Ionicons name="ios-people" size={24} color={tintColor} ></Ionicons >
        )

      })
    },

  },
  {
    tabBarOptions: {
      activeTintColor: '009688',
      inactiveTintColor: '#F8F8F8',
      labelStyle: {
        fontSize: 15,
        fontWeight: 'bold'

      },
      style: {
        backgroundColor: '#4DB6AC',
      },
    }

  }
);

const BigStack = createStackNavigator({
  SplashScreen: SplashScreen,
  OnboardingScreen: OnboardingScreen,
  Login: Login, 
  mainNavigator,
  Map: Map
},
  {

    defaultNavigationOptions: {
      header: null,
    }
  }
)
const App1 = createAppContainer(PostsStack);
const App2 = createAppContainer(BigStack);




export default class App extends Component {

  render() {
    return (
      // <App1/>
      <App2 />


    );
  }
}
