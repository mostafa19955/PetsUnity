import firebase from 'firebase';

var config = {
    apiKey: "AIzaSyB66Gvw-qyVbf_iFT7XMyHg1C6MaTR0Xvw",
    authDomain: "petsunity-6a7bc.firebaseapp.com",
    databaseURL: "https://petsunity-6a7bc.firebaseio.com",
    projectId: "petsunity-6a7bc",
    storageBucket: "petsunity-6a7bc.appspot.com",
    messagingSenderId: "44908563377"
};
firebase.initializeApp(config);
export const f = firebase;
export const auth = firebase.auth();
export const database = firebase.database();
export const storage = firebase.storage();
