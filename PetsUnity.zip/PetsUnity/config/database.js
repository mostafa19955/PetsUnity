import { f, database, auth, storage } from './Config';


const getData = () => {
    database.ref('/stores').once('value').then(snapshot => {
        let data = snapshot.val();
        if (data) {
            // console.log(data)
            data.map((storekey=>{
                console.log(data[storekey])
            }))
            for (storekey in data) {
                console.log(data[storekey])
            
            }
        }
        else {
            console.log('no data')
        }
    }
    )
}
export default getData;