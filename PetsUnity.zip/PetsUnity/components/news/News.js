import React, { Component } from 'react';
import { Text, View, FlatList, Image, TouchableOpacity, ActivityIndicator, StatusBar } from 'react-native';
import { Card, CardItem, Body, Content, Right, Left, Icon, Container, Title , Header} from 'native-base';
import Ionicons from 'react-native-vector-icons/Ionicons';
import { f, database, storage, auth } from '../../config/Config';

export default class News extends Component {
  constructor(props) {
    super(props)
    this.state = {
      newsData: [],
      refresh: false,
      loading: true
    }
  }

  loadingFeed = () => {
    this.setState({
      refresh: true,
      loading: true,
      newsData: []
    })
    f.database().ref('/news').once('value').then(snapShot => {

      let data = snapShot.val()
      if (data) {
        let incomeData = [];
        for (newKey in data) {
          incomeData.push(data[newKey])
        }
        this.setState({ newsData: incomeData })
        this.setState({
          refresh: false,
          loading: false
        })
      } else {
        alert('no data')
      }
    }).catch(error => console.log(error))
  }

  componentDidMount = () => {
    this.loadingFeed()
  }
  render() {
    return (
      <Container>
<Header style={{ backgroundColor: 'transparent'}}>
<Left>
<Image style={{ width: 30, height: 30, left:'2%'}} source={require('../../images/logo.png')} />


 </Left>
<Body>
  <Title style={{ color: 'black', marginLeft:"55%"}}>News</Title>
</Body>
<Right>
<TouchableOpacity transparent onPress={() => {
  this.props.navigation.navigate('Profile')
}}>
            <Ionicons name="ios-contact" size={30} color="grey"></ Ionicons >

 </TouchableOpacity>
</Right>
</Header>

<StatusBar backgroundColor="#009688" barStyle="light-content" />
        {this.state.loading ? (
          <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
                      <ActivityIndicator animating size="large" />

            <Text>Loading</Text>
          </View>
        ) : (
            <FlatList
              refreshing={this.state.refresh}
              onRefresh={this.loadingFeed}
              keyExtractor={(item, index) => index.toString()}
              data={this.state.newsData}
              style={{ flex: 1, backgroundColor: "#eee" }}
              renderItem={({ item, index }) => (
                <Content padder>
                  <Card>
                    <CardItem>
                      <Left>
                        <Body>
                          <Text style={{fontWeight:'bold'}}>{item.title}</Text>
                          <Text style={{fontSize:10}} note>Source:{item.source}</Text>
                        </Body>
                      </Left>
                    </CardItem>
                    <CardItem cardBody>
                      <Image source={{ uri: item.image }} style={{ height: 250, width: null, flex: 1 }} />
                    </CardItem>
                    <CardItem>
                      <Left>
                        <Text numberOfLines={1} >
                          {item.content} ..
                      </Text>
                      </Left>
                      <Right>
                      
                        <TouchableOpacity  onPress={() => {
                            this.props.navigation.navigate('NewsDetails', {
                              title: item.title,
                              image: item.image,
                              content: item.content,
                              source: item.source
                            });
                          }}>
                          <View style={{flexDirection:'row'}}>
                          <Text style={{color:'#009688', marginRight:'5%'}}>See more</Text>
                          <Icon name="arrow-forward"
                          color='gray' />
                          </View>
                          </TouchableOpacity>

                      </Right>



                    </CardItem>
                  </Card>
                </Content>



                // <View style={{borderBottomWidth: 1, borderColor: 'grey', marginBottom: 15}}>
                //   <View key ={index}>
                //     <Text style={{padding: 10, fontWeight: 'bold'}}>{item.title}</Text>
                //   </View>
                //   <View>
                //     <Image 
                //       source={{uri: item.image}} 
                //       style={{resizeMode: 'cover', width:"100%", height: 275}}
                //     />
                //   </View>
                //   <View style={{padding: 10}}>
                //     <Text style={{marginBottom: 5}}>source: {item.source}</Text>
                //     <Text style={{marginBottom: 10}}>{item.content}</Text>
                //     <TouchableOpacity style={{padding: 5, backgroundColor: "#cec"}}  onPress={() => {
                //   this.props.navigation.navigate('NewsDetails', {
                //     title: item.title,
                //       image: item.image,
                //       content: item.content,
                //       source:item.source
                //   });
                // }}>
                //       <Text style={{padding: 5, fontWeight: 'bold', textAlign: 'center'}}>View Details</Text>
                //     </TouchableOpacity>
                //   </View>
                // </View>
              )}
            />
          )}
</Container>
    );
  }
}