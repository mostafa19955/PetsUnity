import React, { Component } from 'react';
import { Text, Image, TouchableOpacity, StatusBar } from 'react-native';
import { Card, CardItem, Body, Content, Left, Icon, Container, Title, Header } from 'native-base';

export default class NewsDetails extends Component {
  constructor(props) {
    super(props)
    this.state = {
      articleObj: {}
    }

  }

  render() {
    const { navigation } = this.props;
    const title = navigation.getParam('title', 'NO-ID');
    const image = navigation.getParam('image', 'NO-ID');
    const content = navigation.getParam('content');
    const source = navigation.getParam('source');
    return (
      <Container>


        <Header style={{ backgroundColor: 'transparent' }}>
          <Left>
            <TouchableOpacity onPress={() => {
              this.props.navigation.navigate('News')
            }}>
              <Icon name='arrow-back' />
            </TouchableOpacity>
          </Left>
          <Body>
            <Title style={{ color: 'black'}}>{title}</Title>
          </Body>
        </Header>

        <StatusBar backgroundColor="#009688" barStyle="light-content" />
        <Content padder>
          <Card>
            <CardItem>
              <Left>
                <Body>
                  <Text style={{ fontWeight: 'bold' }}>{title}</Text>
                  <Text style={{ fontSize: 10 }} note>Source:{source}</Text>
                </Body>
              </Left>
            </CardItem>
            <CardItem cardBody>
              <Image source={{ uri: image }} style={{ height: 250, width: null, flex: 1 }} />
            </CardItem>
            <CardItem>
              <Left>
                <Text >
                  {content}
                </Text>
              </Left>



            </CardItem>
          </Card>
        </Content>



      </Container>
    );
  }
}