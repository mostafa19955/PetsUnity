import React, { Component } from 'react';
import { Text, View, FlatList, Image, TouchableOpacity, ActivityIndicator, StatusBar, TextInput, ToastAndroid } from 'react-native';
import { Card, CardItem, Body, Content, Thumbnail, Right, Left, Icon, Container, Header, Title, Button } from 'native-base';
import Ionicons from 'react-native-vector-icons/Ionicons';
import { f, database, storage, auth } from '../../config/Config';

export default class Posts extends Component {

  constructor(props) {
    super(props)
    this.state = {
      posts: [],
      refresh: false,
      loading: true,
      text: ''
    }
  }
  convert = (timestamp) => {
    var months_arr = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    var date = new Date(timestamp * 1000);
    var year = date.getFullYear();
    var month = months_arr[date.getMonth()];
    var day = date.getDate();
    var hours = date.getHours();
    var minutes = "0" + date.getMinutes();
    var convdataTime = day + '-' + month + '-' + year + ' ' + hours + ':' + minutes.substr(-2);
    return convdataTime;
  }
  loadingPosts = () => {
    this.setState({
      refresh: true,
      loading: true,
      newsData: []
    })
    f.database().ref('/allposts').once('value').then(snapShot => {
      let data = snapShot.val()
      if (data) {
        let incomeData = [];
        for (postKey in data) {
          let postObj = data[postKey]
          f.database().ref('/users').child(postObj.autherId).child('name').once('value').then(snapShot => {
            let userData = snapShot.val()
            if (userData) {
              incomeData.push({
                id: postKey,
                content: postObj.content,
                time: this.convert(postObj.time),
                name: userData
              })
              // alert(incomeData.length)
            } else {
              //No doctor return Same Object With No name for doctor
            }
          }).then(response => {
            this.setState({ posts: incomeData })
            this.setState({
              refresh: false,
              loading: false
            })
          })
        }
      } else {
        //Handle This Case in state By Check if no articles .
      }
    }).catch(error => console.log(error))
  }

  componentDidMount = () => {
    this.loadingPosts()
  }
  render() {
    return (
      <Container>
        <Header style={{ backgroundColor: 'transparent' }}>
          <Left>
            <Image style={{ width: 30, height: 30, left: '2%' }} source={require('../../images/logo.png')} />


          </Left>
          <Body>
            <Title style={{ color: 'black', marginLeft: "55%" }}>Posts</Title>
          </Body>
          <Right>
            <TouchableOpacity transparent onPress={() => {
              this.props.navigation.navigate('Profile')
            }}>
              <Ionicons name="ios-contact" size={30} color="grey"> </Ionicons>


            </TouchableOpacity>
          </Right>
        </Header>

        <StatusBar backgroundColor="#009688" barStyle="light-content" />

        <View style={{  borderColor: 'green',
        borderWidth: 0.4,
        paddingBottom: 10}}>
      <TextInput

        style={{  height: 150,
          justifyContent: "flex-start"}}
        underlineColorAndroid="transparent"
        placeholder="what do you want to write ?"
        placeholderTextColor="gray"
        numberOfLines={10}
        multiline={true}
        onChangeText={(text) => this.setState({text})}
        value={this.state.text}
      />
      <TouchableOpacity style={{ justifyContent: 'center', backgroundColor: "#009688", width: '100%' }}
  onPress={()=>{ 
    // alert('post is done');
     ToastAndroid.showWithGravity(
                    'Post is created successfully!',
                    ToastAndroid.SHORT,
                    ToastAndroid.BOTTOM,
                  );
    let id =database.ref('/allposts').push().key; 
    let timeNow=Date.now();
    let timeStamp = Math.floor(timeNow / 1000);
   database.ref('/allposts').child(id).set({
    
      content:this.state.text,
      time:timeStamp,
      postId:id,
      autherId:'user_id_2'
    }).then(res => {
      database.ref('/posts').child('user_id_2').child(id).set({
    
        content:this.state.text,
        time:timeStamp,
        postId:id,
        autherId:'user_id_2'
      }
      )
    }).then(res => {
      database.ref('/comments').child(id).child('comment_id_1').set({
    content:"",
    posttime:timeStamp,
    user_id:'user_id_2'
       
      })
    }).then(res=>{
        this.loadingPosts()
        this.setState({
          text:''
        })
        
    })
  
}

}
  
>
<Text style={{ padding: 5, fontWeight: 'bold', textAlign: 'center' }}>Comment</Text>
</TouchableOpacity>
      
      </View>


{/* 
        <Card transparent>
          <CardItem bordered>
            <Left>
              <TextInput

                style={{
                  height: 150,
                  justifyContent: "flex-start"
                }}
                underlineColorAndroid="transparent"
                placeholder="what do you want to write ?"
                placeholderTextColor="gray"
                numberOfLines={10}
                multiline={true}
                value={this.state.text}
                onChangeText={(text) => this.setState({ text })}
              />
            </Left>
            <Right>
              <TouchableOpacity style={{ justifyContent: 'center', backgroundColor: "#009688"}}
                onPress={() => {
                  alert('Post is created successfully!');
                  // ToastAndroid.showWithGravity(
                  //   'Post is created successfully!',
                  //   ToastAndroid.SHORT,
                  //   ToastAndroid.BOTTOM,
                  // );
                  let id = database.ref('/allposts').push().key;
                  let timeNow = Date.now();
                  let timeStamp = Math.floor(timeNow / 1000);
                  database.ref('/allposts').child(id).set({

                    content: this.state.text,
                    time: timeStamp,
                    postId: id,
                    autherId: 'user_id_2'
                  }).then(res => {
                    database.ref('/posts').child('user_id_2').child(id).set({

                      content: this.state.text,
                      time: timeStamp,
                      postId: id,
                      autherId: 'user_id_2'
                    }
                    )
                  }).then(res => {
                    database.ref('/comments').child(id).child('comment_id_1').set({
                      content: "",
                      posttime: timeStamp,
                      user_id: 'user_id_2'

                    })
                  }).then(res => {
                    this.loadingPosts()
                    this.setState({ text: '' })
                  })

                }

                }
              >
              <Text style={{ padding: 5, fontWeight: 'bold', textAlign: 'center' }}>POST</Text>
              </TouchableOpacity>
            </Right>
          </CardItem>
        </Card>
 */}



        {this.state.loading ? (
          <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
            <ActivityIndicator animating size="large" />
            <Text>Loading</Text>
          </View>
        ) : (
            <FlatList
              refreshing={this.state.refresh}
              onRefresh={this.loadingFeed}
              keyExtractor={(item, index) => index.toString()}
              data={this.state.posts}
              style={{ flex: 1, backgroundColor: "#eee" }}
              renderItem={({ item, index }) => (
                <Content>
                  <Card>
                    <CardItem>
                      <Left>
                        <Thumbnail source={require('../../images/avatar.png')} />
                        <Body>
                          <Text>{item.name}</Text>
                          <Text note>{item.comment}</Text>
                        </Body>
                      </Left>
                    </CardItem>

                    <CardItem>
                      <Left>
                        <Button transparent>
                          <Icon active name="thumbs-up" />
                          <Text>12 Likes</Text>
                        </Button>
                      </Left>
                      <Body>
                        <Button transparent
                          onPress={() => {
                            this.props.navigation.navigate('PostDetails', {
                            });
                          }}>
                          <Icon active name="chatbubbles" />
                          <Text>4 Comments</Text>
                        </Button>
                      </Body>

                      <Right>
                        <Text>{item.time}</Text>
                      </Right>
                    </CardItem>
                  </Card>
                </Content>
              )}
            />
          )}
      </Container>
    );
  }
}
