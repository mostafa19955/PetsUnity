import React, {Component} from 'react';
import { Platform, StyleSheet, TextInput, View, Text, FlatList, Image, TouchableOpacity, StatusBar, ActivityIndicator } from 'react-native';
import { f, database, storage, auth } from '../../config/Config';
import { Thumbnail, Body, Card, CardItem, Content, Container, Header, Title, Left, Icon, Button, Right} from 'native-base';

export default class PostDetails extends Component {
    constructor(props) {
        super(props)
        this.state = {
          text: '',
          
          comments: [],
          refresh: false,
          loading: true
        }
      }
      convert = (timestamp) => {
        var months_arr = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        var date = new Date(timestamp * 1000);
        var year = date.getFullYear();
        var month = months_arr[date.getMonth()];
        var day = date.getDate();
        var hours = date.getHours();
        var minutes = "0" + date.getMinutes();
        var convdataTime = day + '-' + month + '-' + year + ' ' + hours + ':' + minutes.substr(-2);
        return convdataTime;
      }
      loadingComments = () => {
        this.setState({
          refresh: true,
          loading: true,
          newsData: []
        })
        database.ref('/comments').child('post_id_1').once("value").then(snapShot => {
          let data = snapShot.val()
          if (data) {
            let incomeData = [];
            for (postKey in data) {
              let postObj = data[postKey]
              f.database().ref('/users').child(postObj.user_id).child('name').once('value').then(snapShot => {
                let userData = snapShot.val()
                if (userData) {
                  incomeData.push({
    
                    comment: postObj.content,
                    time: this.convert(postObj.posttime),
                    name: userData
                  })
    
                  // alert(incomeData.length)
                } else {
                  //No doctor return Same Object With No name for doctor
                }
              }).then(response => {
                this.setState({ 
                comments: incomeData,
            }
                )
                this.setState({
                  refresh: false,
                  loading: false
                })    
                console.log(this.state.comments);
              })
    
            }
    
          }
          else {
    
          }
        }
    
        ).catch(error => console.log(error))
      }
      componentDidMount = () => {
        this.loadingComments()
      }
    
      render() {
    
        return (
    
          <Container>
            <Header style={{ backgroundColor: 'transparent' }}>
          <Left>
            <TouchableOpacity transparent onPress={() => {
              this.props.navigation.navigate('Posts')
            }}>
              <Icon name='arrow-back' />
            </TouchableOpacity>
          </Left>
          <Body>
            <Title style={{ color: 'black' }}>Comments</Title>
          </Body>
        </Header>
        <StatusBar backgroundColor="#009688" barStyle="light-content" />


            {this.state.loading ? (
              <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
              <ActivityIndicator animating size="large" />
                <Text>Loading</Text>
              </View>
            ) : (
                <FlatList
                  data={this.state.comments}
                  renderItem={({ item, index }) => (
                    <Content>
                    <Card>
                      <CardItem>
                        <Left>
                          <Body>
                            <Text>{item.name}</Text>
                            <Text note>{item.comment}</Text>
                          </Body>
                        </Left>
                      </CardItem>
                     
                      <CardItem>
                        <Left>
                          <Button transparent>
                            <Icon active name="thumbs-up" />
                            <Text>12 Likes</Text>
                          </Button>
                        </Left>
                      
                        <Right>
                          <Text>{item.time}</Text>
                        </Right>
                      </CardItem>
                    </Card>
                  </Content>
                  )}
                />)}
            <TextInput
    
              onChangeText={(text) => this.setState({ text })}
              placeholder='Add a comment........' 
              value={this.state.text}/>
            <TouchableOpacity style={{ padding: 5, justifyContent: 'center', backgroundColor: "#009688", width: '100%' }}
              onPress={() => {
                let commentid = database.ref('/allposts').push().key;
                let timeNow=Date.now();
                let timeStamp = Math.floor(timeNow / 1000);
                database.ref('/comments').child('post_id_1').child(commentid).set(
                  {
                    content: `${this.state.text}`,
                    posttime: timeStamp,
                    user_id: 'user_id_2'
    
                  }
                ).then(response=>{
                  this.loadingComments();
                  this.setState({text:''})
                })
    
              }
    
    
              }>
              <Text style={{ padding: 5, fontWeight: 'bold', textAlign: 'center' }}>Comment</Text>
            </TouchableOpacity>
    
    
          </Container>
        );
      }
    }