import React, { Component } from "react";
import { Text, TouchableOpacity, StatusBar } from 'react-native';
import { Thumbnail, Body, Card, CardItem, Content, Left, Container, Header,Title, Icon } from 'native-base';

export default class ProductDetails extends Component {
    constructor(props) {
        super(props)
    }


    render() {
        const { navigation } = this.props,
            image = navigation.getParam('image', 'NO-ID'),
            name = navigation.getParam('name', 'NO-ID'),
            owner_id = navigation.getParam('owner_id', 'NO-ID'),
            price = navigation.getParam('price', 'NO-ID'),
            discount = navigation.getParam('discount', 'NO-ID'),
            quantity = navigation.getParam('quantity', 'NO-ID');

        return (
           <Container style={{backgroundColor:'#eee'}}>

<Header style={{ backgroundColor: 'transparent'}}>
<Left>
<TouchableOpacity transparent onPress={() => {
  this.props.navigation.navigate('StoreDetails')
}}>
 <Icon name='arrow-back' />
 </TouchableOpacity>
 </Left>
<Body>
  <Title style={{ color: 'black'}}>{name}</Title>
</Body> 
</Header>

<StatusBar backgroundColor="#009688" barStyle="light-content" />

                <Content padder>
                    <Card style={{borderRadius:10, overflow:'hidden'}}>
                        <CardItem>

                            <Thumbnail style={{ height: 200, width: '100%', borderRadius: 8, overflow: "hidden", resizeMode:'contain' }}
                                source={{ uri: image }} />


                        </CardItem>

                        <CardItem>
                            <Body>
                                <Text
                                    style={{ fontSize: 22, textAlign: 'center', fontWeight: 'bold' }}>
                                    {name}

                                </Text>

                                <Text>
                                    Price:
                          {price} EGP (discount: {discount} EGP)
                        </Text>
                                <Text style={{ fontWeight: '400' }}>
                                    Hurry up only {quantity} pieces left!
                        </Text>


                            </Body>
                        </CardItem>


                    </Card>
                </Content>
       </Container>

        );
    }
}
