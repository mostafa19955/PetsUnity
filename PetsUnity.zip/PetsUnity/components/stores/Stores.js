import React, { Component } from 'react';
import { Text, View, FlatList, Image, TouchableOpacity, ActivityIndicator, Button, StatusBar } from 'react-native';
import { Card, CardItem, Body, Content, Thumbnail, Right, Left, Container, Header, Title } from 'native-base';
import Ionicons from 'react-native-vector-icons/Ionicons';
import { f, database, storage, auth } from '../../config/Config';


export default class Stores extends Component {

  constructor(props) {
    super(props)
    this.state = {
      storesData: [],
      refresh: false,
      loading: true
    }

  }

  loadingFeed = () => {
    this.setState({
      refresh: true,
      loading: true,
      storesData: []
    })
    f.database().ref('/stores').once('value').then(snapShot => {
      let data = snapShot.val()
      if (data) {
        let inData = [];
        for (storeKey in data) {
          inData.push(data[storeKey])
        }
        this.setState({ storesData: inData })
        this.setState({
          refresh: false,
          loading: false
        })
      } else {
        alert('no data')
      }
    }).catch(error => console.log(error))
  }

  componentDidMount = () => {
    this.loadingFeed()
  }



  render() {
    return (
      <Container>
 <Header style={{ backgroundColor: 'transparent' }}>
          <Left>
            <Image style={{ width: 30, height: 30, left: '2%' }} source={require('../../images/logo.png')} />


          </Left>
          <Body>
            <Title style={{ color: 'black', marginLeft: "55%" }}>Stores</Title>
          </Body>
          <Right>
            <TouchableOpacity transparent onPress={() => {
              this.props.navigation.navigate('Profile')
            }}>
              <Ionicons name="ios-contact" size={30} color="grey"> </Ionicons>


            </TouchableOpacity>
          </Right>
        </Header>

        <StatusBar backgroundColor="#009688" barStyle="light-content" />


        {this.state.loading ? (
          <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
            <ActivityIndicator animating size="large" />
            <Text>Loading</Text>
          </View>
        ) : (
            <FlatList
              refreshing={this.state.refresh}
              onRefresh={this.loadingFeed}
              keyExtractor={(item, index) => index.toString()}
              data={this.state.storesData}
              style={{ flex: 1, backgroundColor: "#eee" }}
              renderItem={({ item, index }) => (
                <Content padder>
                  <Card transparent style={{borderRadius:10, overflow:'hidden'}}>
                    <CardItem>
                      <Left>
                        <Thumbnail style={{ height: 100, width: 100, borderRadius: 8, overflow: "hidden" }}
                          source={{uri: item.image}} />
                          </Left>
                          </CardItem>
                          <CardItem>
                          <Body>
                        <Text
                          style={{ fontSize: 22, textAlign: 'center' }}>
                          {item.store_name}

                        </Text>
                        <View style={{ flexDirection: 'row' }}>
                        <TouchableOpacity onPress={()=>{
                          this.props.navigation.navigate('Map')
                        }}>

                          <Image style={{ width: 17, height: 17, right: 2 }} source={require('../../images/map-marker.png')} />


                          <Text note>
                            {`${item.branch} ${item.location}`}

                          </Text>
                          </TouchableOpacity>
                          </View>
                      
                         
                    </Body>
                      <Right>
                        <Button
                        color='#009688'
                          title='Details'
                          onPress={() => {
                            this.props.navigation.navigate('StoreDetails', {
                              branch: item.branch,
                              image: item.image,
                              location: item.location,
                              owner_id: item.owner_id,
                              store_name: item.store_name,
                              store_number: item.store_number
                            });
                          }}

                        >
                        </Button>
                        </Right>
                   </CardItem>
                  </Card>
                </Content>
              )}
            />
          )}
      </Container>
    );
  }
}