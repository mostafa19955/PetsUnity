import React, { Component } from "react";
import { Text, View, FlatList, Image, TouchableOpacity, ActivityIndicator, StatusBar } from 'react-native';
import { f, database, storage, auth } from '../../config/Config';
import { Thumbnail, Body, Card, CardItem, Content, Container, Header, Title, Left, Icon } from 'native-base';



export default class StoreDetails extends Component {

  constructor(props) {
    super(props)
    this.state = {
      productsData: [],
      refresh: false,
      loading: true
    }

  }


  loadingFeed = () => {
    this.setState({
      productsData: [],
      loading: true,
      refresh: true
    })
    f.database().ref('/products').child('store_id_1').once('value').then(snapShot => {
      let data = snapShot.val()
      if (data) {
        let inData = [];
        for (productKey in data) {
          inData.push(data[productKey])
        }
        this.setState({
          productsData: inData
        })
        this.setState({
          loading: false,
          refresh: false
        })
      } else {
        alert('no data')
      }
    }).catch(error => console.log(error))
  }

  componentDidMount = () => {
    this.loadingFeed()
  }
  render() {
    const { navigation } = this.props,
      image = navigation.getParam('image', 'NO-ID'),
      store_name = navigation.getParam('store_name', 'NO-ID'),
      owner_id = navigation.getParam('owner_id', 'NO-ID'),
      location = navigation.getParam('location', 'NO-ID'),
      branch = navigation.getParam('branch', 'NO-ID'),
      store_number = navigation.getParam('store_number', 'NO-ID');

    return (
      <Container>


        <Header style={{ backgroundColor: 'transparent' }}>
          <Left>
            <TouchableOpacity transparent onPress={() => {
              this.props.navigation.navigate('Stores')
            }}>
              <Icon name='arrow-back' />
            </TouchableOpacity>
          </Left>
          <Body>
            <Title style={{ color: 'black' }}>{store_name}</Title>
          </Body>
        </Header>

        <StatusBar backgroundColor="#009688" barStyle="light-content" />

        <Content>

          <Content padder>
            <Text style={{ fontSize: 25, fontWeight: 'bold' }}> Store details </Text>
            <Card transparent style={{ borderRadius: 10, overflow: 'hidden' }}>
              <CardItem>
                <Left>
                  <Image style={{ height: 250, width: null, flex: 1 }}
                    source={{ uri: image }} />
                </Left>
              </CardItem>
              <CardItem>
                <Body>
                  <Text
                    style={{ fontSize: 22, textAlign: 'center' }}>
                    {store_name}

                  </Text>

                  <Text>
                    Phone number: {store_number}
                  </Text>
                  <View style={{ flexDirection: 'row' }}>

                  <TouchableOpacity onPress={()=>{
                          this.props.navigation.navigate('Map')
                        }}>
                    <Image style={{ width: 17, height: 17, right: 2 }} source={require('../../images/map-marker.png')} />


                    <Text note>
                      {`${branch} ${location}`}

                    </Text>
</TouchableOpacity>
                  </View>


                </Body>
              </CardItem>
            </Card>

          </Content>
          <Text style={{ fontSize: 25, fontWeight: 'bold', textAlign: 'center' }}> Products</Text>

          {this.state.loading ? (
            <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
              <ActivityIndicator animating size="large" />
              <Text>Loading</Text>
            </View>

          ) : (

              <FlatList
                refreshing={this.state.refresh}
                onRefresh={this.loadingFeed}
                ItemSeparatorComponent={this.itemSeparator}
                keyExtractor={(item, index) => index.toString()}
                numColumns={2}
                data={this.state.productsData}
                style={{ flex: 1, backgroundColor: "#eee" }}
                renderItem={({ item, index }) => (
                  <View style={{ flex: 1, flexDirection: 'column', margin: 1 }}>
                    <Content padder>
                      <Card transparent style={{ borderRadius: 10, overflow: 'hidden', flex: 0 }}>
                        <CardItem>

                          <Thumbnail style={{
                            height: 100, width: 100, borderRadius: 8, overflow: "hidden", justifyContent: 'center',
                            alignItems: 'center', flex: 1
                          }}
                            source={{ uri: item.image }} />

                        </CardItem>
                        <CardItem>
                          <Body>
                            <Text
                              style={{ fontSize: 22, textAlign: 'center', fontWeight: 'bold' }}>
                              {item.name}

                            </Text>

                            <Text>
                              Price:
                          {item.price} EGP discount: {item.discount} EGP
                        </Text>
                            <Text style={{ fontWeight: '400' }}>
                              Hurry up only {item.quantity} pieces left!
                        </Text>


                          </Body>
                        </CardItem>
                        <CardItem>
                          <TouchableOpacity
                            onPress={() => {
                              this.props.navigation.navigate('ProductDetails', {
                                quantity: item.quantity,
                                image: item.image,
                                discount: item.discount,
                                owner_id: item.owner_id,
                                name: item.name,
                                price: item.price
                              })
                            }}

                          >
                            <View style={{ flexDirection: 'row' }}>
                              <Text style={{ color: '#009688', marginRight: '5%', fontSize: 15 }}>Product details</Text>
                              <Icon name="arrow-forward"
                                color='gray' />
                            </View>
                          </TouchableOpacity>
                        </CardItem>

                      </Card>

                    </Content>

                  </View>
                )}

              />
            )}

        </Content>

      </Container>

    );
  }
}

