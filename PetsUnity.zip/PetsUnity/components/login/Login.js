import React, {Component} from 'react';
import { Text, View,AsyncStorage, Image, TouchableOpacity, TextInput, ScrollView, ToastAndroid, ActivityIndicator} from 'react-native';
import {f, database, storage, auth} from '../../config/Config';
import ImagePicker from 'react-native-image-picker';

export default class Login extends Component {
  
  constructor(props) {
    super(props) 
    this.state = {
      login: true, //back again to false after finish UI,
      newName: '',
      newUserName: '',
      loggin: false,
      signup: false,
      logginEmail: '',
      logginPassword: '',
      signUpEmail: '',
      signUpPassword: '',
      signUpName: '',
      signUpImage: '',
      imageSlected: false,
      imageId: '',
      uploading: false,
    }
  }

  componentDidMount = () => {
    // f.auth().onAuthStateChanged(userObj => {
    //   if(userObj) {
    //     this.setState({login: true})
    //   }else {
    //     this.setState({login:false})
    //   }
    // })
  }

  uniqueId = () => {
    var dt = new Date().getTime();
    var uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
        var r = (dt + Math.random()*16)%16 | 0;
        dt = Math.floor(dt/16);
        return (c=='x' ? r :(r&0x3|0x8)).toString(16);
    });
    return uuid;
}

goToMainNavigation = () => {
  this.props.navigation.navigate('mainNavigator');
}

  backtoChoose = () => {
    this.setState({loggin: false, signup: false})
  }

  loggin = () => {
    this.setState({loggin: true})
  }

  signup = () => {
    this.setState({signup: true})
  }

  logginWithEmailAndPassword = async () => {
    // this.setState({loggin: false, signup: false})
    this.setState({uploading: true, loggin: false, signup: false})
    let email = this.state.logginEmail;
    let password = this.state.logginPassword;

    let resp = await f.auth().signInWithEmailAndPassword(email, password).catch(error => {
      // alert('Error')
      ToastAndroid.showWithGravity(
        'Error',
        ToastAndroid.SHORT,
        ToastAndroid.BOTTOM,
      );
      this.setState({uploading: false, loggin: true, signup: false})
    })
      f.auth().onAuthStateChanged(user => {
        if(user) {
          // alert('success')
          ToastAndroid.showWithGravity(
            'Logged in successfully!',
            ToastAndroid.SHORT,
            ToastAndroid.BOTTOM,
          );
          AsyncStorage.setItem("home", "yes").then(res => {
            this.goToMainNavigation();  
          })   
        }else {
          // alert('Enter a valid Email and Password');
          ToastAndroid.showWithGravity(
            'Enter a valid email and password',
            ToastAndroid.SHORT,
            ToastAndroid.BOTTOM,
          );
          this.setState({uploading: false, loggin: false, signup: false})
        }
    })
  }

  loginWithFacebook = () => { 
 
  }

  signUpWithEmailAndPassword = (downloadURL, signUpEmail, signUpPassword, signUpName) => {
    f.auth().createUserWithEmailAndPassword(signUpEmail, signUpPassword).then(resp => {
      f.auth().onAuthStateChanged(user => {
        if(user) {
          this.createUserinDB(signUpEmail, signUpName, downloadURL)
        }else {
          // alert('Enter a valid Email and Password');
          ToastAndroid.showWithGravity(
            'Enter a valid email and password',
            ToastAndroid.SHORT,
            ToastAndroid.BOTTOM,
          );
          this.setState({uploading: false, loggin: false, signup: false})
        }
      })
    }).catch(error => {
      alert(error)
      this.setState({uploading: false, loggin: false, signup: true})
    })
  }

  createUserinDB = (email, name, downloadURL) => {
    let userObj = {
      name: name,
      email: email,
      image: downloadURL,
      posts: {
        post_id: 'no_post_id'
      }
    }
    f.auth().onAuthStateChanged(user => {
      if(user) {
        f.database().ref('/users').child(user.uid).set(userObj);
        // alert('your profile is Created')
        ToastAndroid.showWithGravity(
          'your profile is Created',
          ToastAndroid.SHORT,
          ToastAndroid.CENTER,
        );
        this.setState({uploading: false})
        AsyncStorage.setItem("home", "yes").then(res => {
          this.props.navigation.navigate('mainNavigator');
        })
      }else{
        // alert('Not Found');
        ToastAndroid.showWithGravity(
          'Not found',
          ToastAndroid.SHORT,
          ToastAndroid.BOTTOM,
        );
      }
    }) 
  }

  
    selectImage = () => {
      ImagePicker.showImagePicker(
        {title: "Select an avatar", storageOptions: {
        skipBackup: true,
        path: 'images',
        }}, (response) => {
        console.log('Response = ', response);
        if (response.didCancel) {
          this.setState({
            imageSlected: false
          })
        } else if (response.error) {
          alert(response.error);
        } else {
          this.setState({
            avatarSource: response.uri,
            imageSlected: true,
            imageId: this.uniqueId()
          });
        }
      });
    }
   

  uploadImage = async (uri='') => {
    if(this.state.signUpEmail.trim() !== '' || this.state.signUpPassword.trim() !== '' || this.state.signUpName.trim() !== '') {
      this.setState({uploading: true})
      let signUpEmail = this.state.signUpEmail ; 
      let signUpPassword = this.state.signUpPassword ;
      let signUpName = this.state.signUpName ; 
      if(uri !== '') {
        const blob = await new Promise((resolve, reject) => {
          const xhr = new XMLHttpRequest();
          xhr.onload = function() {
            resolve(xhr.response);
          };
          xhr.onerror = function() {
            reject(new TypeError('Network request failed'));
          };
          xhr.responseType = 'blob';
          xhr.open('GET', uri, true);
          xhr.send(null);
        });
        let filePath = this.state.imageId;
        const uploadImageToDB = f.storage().ref('/user/'+`${this.state.imageId}`+'/img').child(filePath).put(blob).catch(error => alert(error));
        const downloadURL = await uploadImageToDB.ref.getDownloadURL()
        this.signUpWithEmailAndPassword(downloadURL, signUpEmail, signUpPassword, signUpName)
      }else{
        let downloadURL = "https://firebasestorage.googleapis.com/v0/b/petsunity-6a7bc.appspot.com/o/logo.jpg?alt=media&token=5c477223-cb6e-4805-8101-ce623a4d9bac";
        this.signUpWithEmailAndPassword(downloadURL, signUpEmail, signUpPassword, signUpName)
      }
    }else{
      // alert('please , Enter a valid Email and Password')
      ToastAndroid.showWithGravity(
        'Enter a valid email and password',
        ToastAndroid.SHORT,
        ToastAndroid.BOTTOM,
      );
    }
  }


  render() {
    return (
      <View style={{flex: 1}}>
        <View style={{width: "100%", justifyContent: 'center', alignItems: 'center',backgroundColor: 'white',borderBottomColor: 'grey', borderBottomWidth: 0.5, padding: 20, height: 70}}>
            <Text>Welcome</Text>
            <TouchableOpacity onPress={() => this.goToMainNavigation()}>
              <Text></Text>
            </TouchableOpacity>
        </View> 

          <View style={{flex:1}}>
          <View style={{flex: 1, alignItems: 'center', justifyContent: 'center'}}>
                                  {
                                    this.state.uploading ? (
                                      <View>
                                        <ActivityIndicator size="small" color="blue"/>
                                        <Text>Loading ...</Text>
                                      </View>
                                    ) : (
                                      <View style={{flex:1, alignItems: 'center', justifyContent: 'center'}}>
                                        {
                                          this.state.loggin ? (
                                            <View style={{alignItems: 'center'}}>
                                              <Text style={{fontWeight: 'bold' , margin: 10}}>Log in</Text>
                                              <TextInput
                                                placeholder="Enter Email address here" 
                                                style={{padding: 10 , borderWidth: 0.5, borderColor: "grey", borderRadius: 50, width: 300, margin: 10 }}
                                                onChangeText={(text) => this.setState({logginEmail: text})}
                                                value={this.state.logginEmail}
                                              />
                                              <TextInput 
                                                placeholder="Enter password here"
                                                style={{padding: 10 , borderWidth: 0.5, borderColor: "grey", borderRadius: 50, width: 300, margin: 10 }}
                                                secureTextEntry={true}
                                                onChangeText={(text) => this.setState({logginPassword: text})}
                                                value={this.state.logginPassword}
                                              />
                                              <TouchableOpacity
                                              style={{backgroundColor: "#cec", margin: 15, width: 200, padding: 20, borderRadius: 100, margin: 10}}
                                              onPress={() => this.logginWithEmailAndPassword()} 
                                              >
                                                <Text style={{fontWeight: 'bold', textAlign: 'center'}}>log in</Text>
                                              </TouchableOpacity>
                                              <TouchableOpacity
                                              style={{backgroundColor: "#cec", margin: 15, width: 200, padding: 20, borderRadius: 100}}
                                              onPress={() => this.backtoChoose()} 
                                              >
                                                <Text style={{fontWeight: 'bold', textAlign: 'center'}}>Back</Text>
                                              </TouchableOpacity>
                                            </View>
                                          ) : ( 
                                            <View>
                                            {this.state.signup ? (
                                            <ScrollView>
                                            <View style={{flex: 1, alignItems: 'center'}}> 
                                              <TouchableOpacity
                                                style={{backgroundColor: "#cec", margin: 5, width: 200, padding: 20, borderRadius: 100}}
                                                onPress={() => this.backtoChoose()} 
                                                >
                                                  <Text style={{fontWeight: 'bold', textAlign: 'center'}}>Back</Text>
                                              </TouchableOpacity>
                                              {
                                                this.state.imageSlected ? (
                                                  <Image source={{uri: this.state.avatarSource}} style={{width: 100, height: 100, borderRadius: 50}} />
                                                ): (
                                                  <Image source={require('../../images/avatar.png')} style={{width: 100, height: 100, borderRadius: 50}} />
                                                )
                                              }
                                              <TextInput
                                                style={{padding: 10 , borderWidth: 0.5, borderColor: "grey", borderRadius: 50, width: 300, margin: 10 }}
                                                placeholder="Enter your name here:" 
                                                onChangeText={(text) => this.setState({signUpName: text})}
                                                value={this.state.signUpName}
                                              />
                                              <TextInput
                                                style={{padding: 10 , borderWidth: 0.5, borderColor: "grey", borderRadius: 50, width: 300, margin: 10 }}
                                                placeholder="Enter Email address here" 
                                                onChangeText={(text) => this.setState({signUpEmail: text})}
                                                value={this.state.signUpEmail}
                                              />
                                              <TextInput 
                                                placeholder="Enter password here"
                                                style={{padding: 10 , borderWidth: 0.5, borderColor: "grey", borderRadius: 50, width: 300, margin: 10 }}  
                                                secureTextEntry={true}
                                                onChangeText={(text) => this.setState({signUpPassword: text})}
                                                value={this.state.signUpPassword}
                                              />
                                              <TouchableOpacity
                                              style={{margin: 15, width: 200, padding: 20, borderRadius: 100, margin: 10, borderBottomWidth: .5}}
                                              onPress={() => this.selectImage()} 
                                              >
                                                <Text style={{fontWeight: 'bold', textAlign: 'center'}}>choose profile Image</Text>
                                              </TouchableOpacity>
                                              <TouchableOpacity
                                              style={{backgroundColor: "#cec", margin: 15, width: 200, padding: 20, borderRadius: 100, margin: 10}}
                                              onPress={() => this.uploadImage()} 
                                              >
                                                <Text style={{fontWeight: 'bold', textAlign: 'center'}}>sign up</Text>
                                              </TouchableOpacity>
                                            </View>
                                            </ScrollView>
                                            ) : (
                                            <View style={{alignItems: 'center'}}>
                                              <TouchableOpacity
                                              style={{backgroundColor: "#cec", margin: 15, width: 200, padding: 20, borderRadius: 100}}
                                              onPress={() => this.loggin()} 
                                              >
                                                <Text style={{fontWeight: 'bold', textAlign: 'center'}}>log in</Text>
                                              </TouchableOpacity>
                                              <Text>- or -</Text>
                                              <TouchableOpacity 
                                                style={{backgroundColor: "#cee", margin: 15, width: 200, padding: 20, borderRadius: 100}}
                                                onPress={() => this.signup()}  
                                              >
                                                <Text style={{fontWeight: 'bold', textAlign: 'center'}}>sign up</Text>
                                              </TouchableOpacity> 
                                            </View>
                                            )}
                                            </View>    
                                          )
                                        }
                                      </View>
                                    )
                                  }
            </View>
          </View>
      </View>  
    );
  }
}
