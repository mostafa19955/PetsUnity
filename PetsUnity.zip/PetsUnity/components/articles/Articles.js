import React, { Component } from 'react';
import { Text, View, FlatList, Image, TouchableOpacity, ActivityIndicator, StatusBar } from 'react-native';
import { Card, CardItem, Body, Right, Left, Icon, Container, Header, Title } from 'native-base';
import  Ionicons  from 'react-native-vector-icons/Ionicons';
import { f, database, storage, auth } from '../../config/Config';
export default class Articles extends Component {

  constructor(props) {
    super(props)
    this.state = {
      articlesData: [],
      refresh: false,
      loading: true
    }
  }

  loadingFeed = () => {
    this.setState({
      refresh: true,
      loading: true,
      newsData: []
    })
    f.database().ref('/articles').once('value').then(snapShot => {
      let data = snapShot.val()
      if (data) {
        let incomeData = [];
        for (articleKey in data) {
          let articleObj = data[articleKey]
          f.database().ref('/doctors').child(articleObj.doctor_id).once('value').then(snapShot => {
            let doctorData = snapShot.val()
            if (doctorData) {
              incomeData.push({
                id: articleKey,
                title: articleObj.title,
                image: articleObj.image,
                content: articleObj.content,
                doctorName: doctorData.name
              })
              // alert(incomeData.length)
            } else {
              //No doctor return Same Object With No name for doctor
            }
          }).then(response => {
            this.setState({ articlesData: incomeData })
            this.setState({
              refresh: false,
              loading: false
            })
          })
        }
      } else {
        //Handle This Case in state By Check if no articles .
      }
    }).catch(error => console.log(error))
  }

  componentDidMount = () => {
    this.loadingFeed()
  }

  render() {
    return (
      <Container>
        <Header style={{ backgroundColor: 'transparent' }}>
          <Left>
            <Image style={{ width: 30, height: 30, left: '2%' }} source={require('../../images/logo.png')} />


          </Left>
          <Body>
            <Title style={{ color: 'black', marginLeft: "55%" }}>Articles</Title>
          </Body>
          <Right>
            <TouchableOpacity transparent onPress={() => {
              this.props.navigation.navigate('Profile')
            }}>
              <Ionicons name="ios-contact" size={30} color="grey"> </Ionicons>


            </TouchableOpacity>
          </Right>
        </Header>

        <StatusBar backgroundColor="#009688" barStyle="light-content" />
        {this.state.loading ? (
          <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
            <ActivityIndicator animating size="large" />
            <Text>Loading</Text>
          </View>
        ) : (
            <FlatList
              refreshing={this.state.refresh}
              onRefresh={this.loadingFeed}
              keyExtractor={(item, index) => index.toString()}
              data={this.state.articlesData}
              style={{ flex: 1, backgroundColor: "#eee" }}
              renderItem={({ item, index }) => (
            
                <Card>
                  <CardItem>
                    <Left>

                      <Text style={{ fontWeight: 'bold' }}>{item.title}</Text>

                    </Left>
                  </CardItem>
                  <CardItem cardBody>
                    <Image source={{ uri: item.image }} style={{ height: 250, width: null, flex: 1 }} />
                  </CardItem>
                  <CardItem>
                    <Left>
                      <Body>
                        <Text numberOfLines={1} >
                          {item.content} ..
                      </Text>

                        <Text style={{ fontSize: 10 }} note>Written by Dr/:{item.doctorName}</Text>
                      </Body>
                    </Left>
                    <Right>

                      <TouchableOpacity
                        onPress={() => {
                          this.props.navigation.navigate('ArticleDetails', {
                            title: item.title,
                            image: item.image,
                            content: item.content,
                            doctorName: item.doctorName
                          });
                        }}
                      >
                        <View style={{ flexDirection: 'row' }}>
                          <Text style={{ color: '#009688', marginRight: '5%' }}>See more</Text>
                          <Icon name="arrow-forward"
                            color='gray' />
                        </View>
                      </TouchableOpacity>

                    </Right>



                  </CardItem>
                </Card>

              )}
            />
          )}

      </Container>
    );
  }
}
