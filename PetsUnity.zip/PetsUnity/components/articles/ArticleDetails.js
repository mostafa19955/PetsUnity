import React, {Component} from 'react';
import { Text, Image, StatusBar} from 'react-native';
import { Card, CardItem, Body, Content, Left, Icon, TouchableOpacity, Container, Header, Title, Button } from 'native-base';


export default class ArticleDetails extends Component {
  
  constructor(props) {
    super(props)
    this.state = {
      articleObj: {}
    }
    
  }

  render() {
    const { navigation } = this.props;
    const title = navigation.getParam('title', 'NO-ID');
    const  image = navigation.getParam('image', 'NO-ID');
    const  content = navigation.getParam('content');
    const  doctorName = navigation.getParam('doctorName');
    return (
      <Container>

<Header style={{ backgroundColor: 'transparent' }}>
<Left>
            {/* <TouchableOpacity onPress={() => {
              this.props.navigation.navigate('Articles')
            }}>
              <Icon name='arrow-back' />
            </TouchableOpacity> */}
            <Button transparent onPress={()=>{
              this.props.navigation.navigate('Articles')
            }}>
<Icon name='arrow-back' />
            </Button>
          </Left>
            
<Body>
  <Title style={{ color: 'black', left: '33%' }}>{title}</Title>
</Body>
</Header>

<StatusBar backgroundColor="#009688" barStyle="light-content" />
<Content padder>
                  <Card>
                    <CardItem>
                      <Left>
                        <Body>
                          <Text style={{fontWeight:'bold'}}>{title}</Text>
                        </Body>
                      </Left>
                    </CardItem>
                    <CardItem cardBody>
                      <Image source={{ uri: image }} style={{ height: 250, width: null, flex: 1 }} />
                    </CardItem>
                    <CardItem>
                      <Left>
                      <Body>
                        <Text >
                          {content}
                      </Text>
                      
                      <Text style={{fontSize:10}} note>Written by Dr/{doctorName}</Text>
                      </Body>
                      </Left>

                    </CardItem>
                  </Card>
                </Content>


      
      </Container>
    );
  }
}