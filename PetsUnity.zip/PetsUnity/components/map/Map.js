import React, { Component } from 'react';
import {WebView} from 'react-native';
import { Container, Header, Left, Body, Right, Button, Icon, Title} from 'native-base';
export default class Map extends Component {
    
  
    render() {
    return (
      <Container>
      <Header>
      <Left>
        <Button transparent onPress={() => {
                       this.props.navigation.goBack()
                    }}>
          <Icon name='arrow-back' />
        </Button>
      </Left>
      <Body>
        <Title>Back</Title>
      </Body>
      <Right>
      </Right>
    </Header>
    <WebView source={{uri: "https://www.google.com/maps/search/?api=1&query=pizza+seattle+wa"}}
                    style={{width: "100%", height: 300}}
    />
   
  </Container>
    
    );
  }
}