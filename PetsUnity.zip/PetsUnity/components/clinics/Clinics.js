import React, { Component } from 'react';
import { Platform, StyleSheet, Text, View, FlatList, Image, TouchableOpacity, Button, ActivityIndicator, StatusBar } from 'react-native';
import { Card, CardItem, Body, Content, Thumbnail, Right, Left, Container, Header, Title } from 'native-base';
import Ionicons from 'react-native-vector-icons/Ionicons';

import { f, database, storage, auth } from '../../config/Config';

export default class Clinics extends Component {
  constructor(props) {
    super(props)
    this.state = {
      ClinicData: [],
      refresh: false,
      loading: true
    }
  }

  loadingFeed = () => {
    this.setState({
      refresh: true,
      loading: true,
      ClinicData: []
    })
    f.database().ref('/clinics').once('value').then(snapShot => {
      let data = snapShot.val()
      if (data) {
        let incomeData = [];
        for (newKey in data) {
          incomeData.push(data[newKey])
        }
        this.setState({ ClinicData: incomeData })
        this.setState({
          refresh: false,
          loading: false
        })
      } else {
        alert('no data')
      }
    }).catch(error => console.log(error))
  }

  componentDidMount = () => {
    this.loadingFeed()
  }


  render() {

    return (
      <Container>

<Header style={{ backgroundColor: 'transparent'}}>
<Left>
<Image style={{ width: 30, height: 30, left:'2%'}} source={require('../../images/logo.png')} />


 </Left>
<Body>
  <Title style={{ color: 'black', marginLeft:"55%"}}>Clinics</Title>
</Body>
<Right>
<TouchableOpacity transparent onPress={() => {
  this.props.navigation.navigate('Profile')
}}>
            <Ionicons name="ios-contact" size={30} color="grey"></ Ionicons >

 </TouchableOpacity>
</Right>
</Header>

<StatusBar backgroundColor="#009688" barStyle="light-content" />
        {this.state.loading ? (
          <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <ActivityIndicator animating size="large" />
            <Text>Loading</Text>
          </View>
        ) : (
            <FlatList
              refreshing={this.state.refresh}
              onRefresh={this.loadingFeed}
              keyExtractor={(item, index) => index.toString()}
              data={this.state.ClinicData}
              style={{ flex: 1, backgroundColor: "#eee" }}
              renderItem={({ item, index }) => (

                <Content padder>
                  <Card transparent style={{borderRadius:10, overflow:'hidden'}}>
                    <CardItem>
                      <Left>
                        <Thumbnail style={{ height: 100, width: 100, borderRadius: 8, overflow: "hidden" }}
                          source={{uri:item.image}} />
                          </Left>
                          </CardItem>
                          <CardItem>
                          <Body>
                        <Text
                          style={{ fontSize: 22, textAlign: 'center' }}>
                          {item.name}

                        </Text>
                        <View style={{ flexDirection: 'row' }}>
                        <TouchableOpacity onPress={()=>{
                          this.props.navigation.navigate('Map')
                        }}>
                          <Image style={{ width: 17, height: 17, right: 2 }} source={require('../../images/map-marker.png')} />


                          <Text note>
                            {`${item.Branch}, ${item.location}`}

                          </Text>
                          </TouchableOpacity>

                          </View>
                      
                         
                    </Body>
                      <Right>
                        <Button
                        color='#009688'
                          title='Details'
                          onPress={() => {
                            this.props.navigation.navigate('ClinicDetails', {
                              ClinicId: item.clinic_id,
                              timing: item.timing,
                              ClinicName: item.name,
                              location: item.location,
                              branch: item.Branch,
                              image: item.image
                            });
                          }}

                        >
                        </Button>
                        </Right>
                        
                   </CardItem>
                  </Card>
                </Content>


              )}
            />
          )}
</Container>
    );
  }
}

