import React, { Component } from 'react';
import { Text, View, Image, TouchableOpacity, StatusBar } from 'react-native';
import { Card, CardItem, Body, Content, Thumbnail, Left, Header, Icon, Title } from 'native-base';
import { f, database, storage, auth } from '../../config/Config';
import { Container } from 'native-base';

export default class ClinicDetails extends Component {
  constructor(props) {
    super(props)
    this.state = {
      ClinicData: [],
    }
  }
  loadingFeed = () => {
    f.database().ref('/clinic_doctors').child(this.props.navigation.getParam('ClinicId', 'NO-ID')).once('value').then(snapShot => {
      let data = snapShot.val()
      if (data) {
        let incomeData = [];
        for (ClinicDoctorKey in data) {
          let ClinicDoctorObj = data[ClinicDoctorKey]
          f.database().ref("/doctors").child(ClinicDoctorObj).once('value').then(snapShot => {
            ClinicDoctorData = snapShot.val()
            if (ClinicDoctorData) {
              incomeData.push({
                doctorname: ClinicDoctorData.name
              })
              this.setState({ ClinicData: incomeData })
            }
          })
        }

      } else {
      }
    }).catch(error => console.log(error))
  }

  componentDidMount = () => {
    this.loadingFeed()
  }
  doctorList = () => {
    return this.state.ClinicData.map((data) => {

      return (
        <View style={{}} ><Text>{data.doctorname}</Text></View>
      )
    })

  }
  render() {
    const { navigation } = this.props;
    const itemId = navigation.getParam('ClinicId', 'NO-ID');
    const timing = navigation.getParam('timing', 'NO-ID');
    const ClinicName = navigation.getParam('ClinicName', 'NO-ID');
    const location = navigation.getParam('location', 'NO-ID');
    const branch = navigation.getParam('branch', 'NO-ID');
    const image = navigation.getParam('image', 'NO-ID');

    return (
      <Container>
        <Header style={{ backgroundColor: 'transparent'}}>
<Left>
<TouchableOpacity transparent onPress={() => {
  this.props.navigation.navigate('Clinics')
}}>
 <Icon name='arrow-back' />
 </TouchableOpacity>
 </Left>
<Body>
  <Title style={{ color: 'black'}}>{ClinicName}</Title>
</Body> 
</Header>

<StatusBar backgroundColor="#009688" barStyle="light-content" />
        <Content padder>
          <Card style={{ borderRadius: 10, overflow: 'hidden' }}>
            <CardItem>
              <Left>
                <Thumbnail style={{ height: 100, width: 100, borderRadius: 8, overflow: "hidden", resizeMode:'contain' }}
                  source={{uri:image}} />
              </Left>
            </CardItem>
            <CardItem>
              <Body>
                <Text
                  style={{ fontSize: 22, textAlign: 'center' }}>
                  {ClinicName}
                </Text>
                <Text note>
                  {timing}
                </Text>
                <View style={{ flexDirection: 'row' }}>
                  <Text>
                    Dr/ </Text>
                  {this.doctorList()}
                </View>
                <View style={{ flexDirection: 'row' }}>
                <TouchableOpacity onPress={()=>{
                          this.props.navigation.navigate('Map')
                        }}>
                  <Image style={{ width: 17, height: 17, right: 2 }} source={require('../../images/map-marker.png')} />
                  <Text note>
                    {`${branch} ${location}`}
                  </Text>
                  </TouchableOpacity>
                </View>

              </Body>

            </CardItem>
          </Card>
        </Content>
      </Container>
    );
  }
}