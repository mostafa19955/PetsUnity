import React, {Component} from 'react';
import { Text, View, FlatList, Image, TouchableOpacity, TextInput, StatusBar, ActivityIndicator} from 'react-native';
import { f, database, storage, auth } from '../../config/Config';
import { Container } from 'native-base';


export default class Profile extends Component {
    constructor(props) {
        super(props)
        this.state = {
          login: true, //back again to false after finish UI,
          data: [],
          dataExist: false,
          refresh: false,
          loading: true,
          profile: false,
          newName: '',
          newUserName: ''
        }
      }
    
      componentDidMount = () => {
        this.loadPosts()
      }
    
      changeProfile = () => {
        this.setState({profile: true})
      }
    
      saveNewData = () => {
        if(this.state.newName || this.state.newUserName) {
          this.setState({
            profile: false,
            newName: '',
            newUserName: ''
          })  
        }
      }
    
      loadPosts = () => {
        this.state = {
          data: [],
          refresh: true
        }
        f.database().ref('/posts').child('user_id_2').once('value').then(snapShot => {
          let data = snapShot.val();
          if (data) {
            let incomeData = [];
            for(postKey in data) {
              let postObj = data[postKey];
              incomeData.push(postObj)
            }
            this.setState({
              data: incomeData,
              dataExist: true,
              loading: false,
              refresh: false
            })
          }else {
            //return state data false to appear no posts and make user Create new post
            this.setState({
              data: [],
              loading: false,
              refresh: false, 
              dataExist: false
            })
          }
        })
      }
    
      render() {
        return (
          <Container>
          <View style={{width: "100%", justifyContent: 'center', alignItems: 'center',backgroundColor: 'white',borderBottomColor: 'grey', borderBottomWidth: 0.5, padding: 20, height: 70}}>
              <Text>Profile</Text>
          </View>
          
         <StatusBar backgroundColor="#009688" barStyle="light-content" />
          {
            this.state.login ? (
              <View style={{flex:1}}>
                <View style={{flexDirection: 'row', alignItems: 'center', justifyContent: 'space-around'}}>
                  <View style={{margin: 10}}>
                    <Image source={{uri: "https://loremflickr.com/320/366/dog"}} style={{width: 100 , height: 100, borderRadius: 70}}/> 
                  </View>
                  <View style={{margin: 10}}> 
                    <Text>Dahy saied</Text>
                    <Text>@dahysaied</Text>
                  </View>
                </View>
                <View style={{alignItems: 'center'}}>
                    <TouchableOpacity 
                      style={{padding: 10, backgroundColor: "#009688", borderRadius: 5, width: 200}}
                      onPress={() => this.changeProfile()}  
                    >
                      <Text style={{textAlign: 'center', color: 'green'}}>Edit Profile</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={{padding: 10, backgroundColor: "#009688", borderRadius: 5, width: 200, margin: 5}}>
                      <Text style={{textAlign: 'center', color: 'green'}}>Log out</Text>
                    </TouchableOpacity>
                </View>
                {
                      this.state.profile ? (
                        <View style={{flex: 1, alignItems: 'center', justifyContent: 'center'}}>
                          <Text>Change Profile</Text>
                          <TextInput 
                            placeholder="Enter new name here"
                            onChangeText={(text) => this.setState({newName: text})}
                            value={this.state.newName}
                          />
                          <TextInput 
                            placeholder="Enter user name here"
                            onChangeText={(text) => this.setState({newUserName: text})}
                            value={this.state.newUserName}
                          />
                          <TouchableOpacity 
                            style={{padding: 10, backgroundColor: "#009688", borderRadius: 5, width: 200, margin: 5}}
                            onPress={() => this.saveNewData()}
                          >
                            <Text style={{textAlign: 'center', color: 'green'}}>Save</Text>
                          </TouchableOpacity>
                        </View>
                      ):(
                        
                        <View style={{flex:1, backgroundColor: '#eee'}}>
                        <Text style={{textAlign: 'center'}}>Your Posts</Text>
                        {
                          this.state.loading ? (
                            <View style={{flex:1, alignItems: 'center', justifyContent: 'center'}}>
                                        <ActivityIndicator animating size="large" />

                              <Text>Loading</Text>
                            </View>
                          ) : (
                          <View style={{flex:1}}>
                           {
                            this.state.dataExist ? (
                              <FlatList 
                                refreshing={this.state.refresh}
                                onRefresh={this.loadPosts}
                                keyExtractor={(item,index) => index.toString()}
                                data={this.state.data}
                                style={{flex:1, backgroundColor:"#eee"}}
                                renderItem={({item,index}) => (
                                <View style={{border: 1, borderRadius: 3, borderWidth: 0.5, borderColor: "grey", borderColor: 'grey', margin: 5}}>
                                  <View key ={index}>
                                    <Text style={{padding: 10, fontWeight: 'bold', fontSize: 20}}>{item.content}</Text>
                                  </View>
                                  <View style={{padding: 10}}>
                                      <Text style={{marginBottom: 5,fontWeight: 'bold', fontSize: 14}}>{item.time} ago</Text>
                                  </View>
                                  <View style={{alignItems: 'center'}}>
                                  <TouchableOpacity style={{padding: 10, backgroundColor: "#009688", borderRadius: 5, width: 200, margin: 5}}>
                                     <Text style={{textAlign: 'center', color: 'white'}}>View comments</Text>
                                   </TouchableOpacity>
                                  </View>  
                                </View>
                                )}
                              /> 
                            ):(
                              <View style={{flex: 1, alignItems: 'center', justifyContent: 'center'}}>
                                <Text>No posts</Text>
                                <TouchableOpacity style={{padding: 10 , margin: 5, backgroundColor: "#009688", borderRadius: 5, width: 200}}>
                                  <Text style={{textAlign: 'center', color: 'white'}}>Create Post</Text>
                                </TouchableOpacity>
                              </View>
                            )
                          }
                        </View>
                      )
                    }
                </View>
                  )} 
              </View>
            ) : (
              <View style={{flex: 1, alignItems: 'center', justifyContent: 'center'}}>
                <Text style={{fontWeight: 'bold'}}>You are not logged in</Text>
                <Text style={{fontWeight: 'bold'}}>Login</Text>
                <Text style={{fontWeight: 'bold'}}>Sign up</Text>
              </View>
            )}
          </Container>
        );
      }
}