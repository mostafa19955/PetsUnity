import React, { Component } from 'react';
import { View,Image, AsyncStorage} from 'react-native';
export default class SplashScreen extends Component {
    componentDidMount(){
        AsyncStorage.getItem("home").then((value)=>{
        if(value === 'yes'){
        setTimeout(()=>{ this.props.navigation.navigate('mainNavigator', ) },3000);
       
        }
        else if(value === 'ok')
        {
         setTimeout(()=>{ this.props.navigation.navigate('Login',  ) },3000);
        }
         else 
         {
         setTimeout(()=>{this.props.navigation.navigate('OnboardingScreen', ) },3000);
         }
     })
        }
        
    render() {
        return ( 
            < View style={{backgroundColor:"white"}}  style={{flex:1, alignItems:'center',justifyContent:'center'}}>
              <Image   style={{ width:150,height:150}} source={require('../images/splash.png')} />
            </View>
          );
}
}
