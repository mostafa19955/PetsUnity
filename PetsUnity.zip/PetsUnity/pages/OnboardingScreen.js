import React, {Component} from 'react';
import { StyleSheet ,AsyncStorage} from 'react-native';
import Login from '../components/login/Login';
import AppIntroSlider from 'react-native-app-intro-slider';
_renderItem = (item) => {
  return (
    <View style={styles.slide}>
      <Text style={styles.title}>{item.title}</Text>
      <Image source={item.image} />
      <Text style={style.text}>{item.text}</Text>
    </View>
  );
}
const styles = StyleSheet.create({
  image: {
    width: 200 ,
     height: 200, 
     borderRadius: 70
  },
   title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: 'black',
    backgroundColor: 'transparent',
    textAlign: 'center',
    marginTop: 16,
  },text: {
    fontSize: 28,
    fontWeight: 'bold',
    color: 'black',
    backgroundColor: 'transparent',
    textAlign: 'center',
    marginTop: 16,
  },
   buttonCircle: {
    width: 40,
    height: 40,
    backgroundColor: 'rgba(0, 0, 0, .2)',
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
  }
});

const slides = [
  {
    key: 'somethun',
    title: 'News',
    text: 'read new about pets',
    image: require('../images/News.jpg'),
    titleStyle: styles.title,
    textStyle: styles.text,
    imageStyle: styles.image,
    backgroundColor: 'white',
  },
  {
    key: 'somethun-dos',
    title: 'Articles',
    text: 'read useful articles',
    image: require('../images/Article.jpg'),
    titleStyle: styles.title,
    imageStyle: styles.image,
    textStyle: styles.text,
    textStyle: styles.text,
    backgroundColor: 'white',
  },
  {
    key: 'somethun1',
    title: 'Clinics',
    image: require('../images/Clinic.jpg'),
    imageStyle: styles.image,
    textStyle: styles.text,
    text: 'clinic is near from you',
    titleStyle: styles.title,
    backgroundColor: 'white'
  },
  {
    key: 'somethun2',
    title: 'Stores',
    image: require('../images/store.jpg'),
    imageStyle: styles.image,
    titleStyle: styles.title,
    textStyle: styles.text,
    text: 'can see product of store',
    backgroundColor: 'white'
  },
  {
    key: 'somethun3',
    title: 'Posts',
    textStyle: styles.text,
    image: require('../images/post.jpg'),
    titleStyle: styles.title,
    imageStyle: styles.image,
    text: ' can communicate with people like you',
    backgroundColor: 'white',
    buttonTextStyle:styles.text,

  }
];
_renderNextButton = () => {
  return (
    <View style={styles.buttonCircle}>
      <Ionicons
        name="md-arrow-round-forward"
        color="rgba(255, 255, 255, .9)"
        size={24}
        style={{ backgroundColor: 'transparent' }}
      />
    </View>
  );
}


export default class OnboardingScreen extends Component{
  constructor (props) {
    super(props)
    this.state = {
      showRealApp : false 
    }
 }

 _onSkip = () => {
  // User finished the introduction. Show real app through
  // navigation or simply by controlling state
  this.setState({ showRealApp:"true"});
  AsyncStorage.setItem( "home", "ok" )
}
 
  _onDone = () => {
    // User finished the introduction. Show real app through
    // navigation or simply by controlling state
    this.setState({ showRealApp:"true"});
    AsyncStorage.setItem( "home", "ok" )
  }
  render() {
    if (this.state.showRealApp) {
      return <Login />;
    } else {
      return <AppIntroSlider renderItem={this._renderItem}  slides={slides} buttonTextStyle={{color: "black"}} onDone={this._onDone} onSkip={this._onSkip}  showSkipButton={true}  showPrevButton={true}/>;
    }
  }
}
